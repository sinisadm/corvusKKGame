package KKGame;
public abstract class GamePlayers {
	public static String Player1 = "X";
	public static String Player2 = "O";
}